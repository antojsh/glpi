
1 - Proceder a instalação como a de um plugin qualquer, descompactando o arquivo e copiando a pasta para a pasta plugins no servidor de GLPI.

2 - Na interface do GLPI acessar Configurar -> Plugins e efetuar a instalação.

3 - Acessar no menu do GLPI: Plugins -> Dashboard


#############################################################


1 - Perform the installation as any plugin, unzipping the file and copying the folder to the plugins folder in GLPI server.

2 - In the GLPI interface to access Setup -> Plugins for installation.

3 - Get in GLPI Menu: Plugins -> Dashboard


##############################################################

contact: stevenesdonato@gmail.com
